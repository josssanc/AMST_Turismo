package com.example.amst_turismo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void irCosta(View v){
        Intent ventana = new Intent(getBaseContext(), costa.class);
        Toast mensa = Toast.makeText(getApplicationContext(),"https://www.turismo.gob.ec/el-programa-televisivo-ecuador-ama-la-vida-trasciende-fronteras-2/ecuador-ama-la-vida-2/", Toast.LENGTH_SHORT);
        mensa.show();
        startActivity(ventana);
    }
    public void irSierra(View v){
        Intent ventana = new Intent(getBaseContext(), sierra.class);
        Toast mensa = Toast.makeText(getApplicationContext(),"https://www.turismo.gob.ec/el-programa-televisivo-ecuador-ama-la-vida-trasciende-fronteras-2/ecuador-ama-la-vida-2/", Toast.LENGTH_SHORT);
        mensa.show();
        startActivity(ventana);
    }
    public void irAmazonia(View v){
        Intent ventana = new Intent(getBaseContext(), amazonia.class);
        Toast mensa = Toast.makeText(getApplicationContext(),"https://www.turismo.gob.ec/el-programa-televisivo-ecuador-ama-la-vida-trasciende-fronteras-2/ecuador-ama-la-vida-2/", Toast.LENGTH_SHORT);
        mensa.show();
        startActivity(ventana);
    }
    public void irInsular(View v){
        Intent ventana = new Intent(getBaseContext(), insular.class);
        Toast mensa = Toast.makeText(getApplicationContext(),"https://www.turismo.gob.ec/el-programa-televisivo-ecuador-ama-la-vida-trasciende-fronteras-2/ecuador-ama-la-vida-2/", Toast.LENGTH_SHORT);
        mensa.show();
        startActivity(ventana);
    }

}
